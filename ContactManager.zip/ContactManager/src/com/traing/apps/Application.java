package com.traing.apps;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;

import com.training.dao.ContactsDaoImpl;
import com.training.entity.Contacts;
import com.training.ifaces.DataAccess;
import com.training.util.DbConnectionUtil;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		Connection con=DbConnectionUtil.getMySqlConnection();
		DatabaseMetaData metaData=con.getMetaData();
		 System.out.println("Database Metadata:" + metaData.getClass().getName());
		 System.out.println("Database Metadata Connection Url:" + metaData.getURL());
		 System.out.println("Database Metadata Connection Url:" + metaData.getDatabaseProductName());
		}
		catch(SQLException e)
		{
	     e.printStackTrace();
		}
int key=1;
DataAccess<Contacts> dao=new ContactsDaoImpl();
switch (key) {
case 1: {
	Contacts contact1=new Contacts("Suhas", "5 cross", 98457, "img1/1", LocalDate.of(1992, Month.DECEMBER, 12), "suhas@gmail.com");
	int rowAdded=dao.add(contact1);
	System.out.println("Row added" +rowAdded);
	break;
}
case 2:
	dao.findAll().stream().forEach(System.out::println);
	break;

case 4:
	int rowRemoved=dao.remove(101);
	System.out.println("Row Removed" +rowRemoved);
	break;

default:
	throw new IllegalArgumentException("Unexpected value: " + key);
}
	}

}
