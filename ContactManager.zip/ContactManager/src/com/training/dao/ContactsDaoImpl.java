package com.training.dao;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.sql.RowSet;
import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;

import com.training.entity.Contacts;
import com.training.ifaces.DataAccess;
import com.training.util.DbConnectionUtil;

public class ContactsDaoImpl implements DataAccess<Contacts> {

	private Connection con;

	public ContactsDaoImpl(Connection con) {
		super();
		this.con = con;
	}

	public ContactsDaoImpl() {
		super();
		con = DbConnectionUtil.getMySqlConnection();
	}

	@Override
	public int add(Contacts t) {

		String sql = "insert into lumen_contacts values(?,?,?,?,?,?)";
		int rowsAdded = 0;
		try (PreparedStatement pstmt = con.prepareStatement(sql)) {
			pstmt.setString(1, t.getName());
			pstmt.setString(2, t.getAddress());
			pstmt.setLong(3, t.getMobileNumber());
			pstmt.setString(4, t.getImg());
			pstmt.setDate(5, Date.valueOf(t.getDateOfBirth()));
			pstmt.setString(6, t.getEmail());

			rowsAdded = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowsAdded;
	}

	@Override
	public List<Contacts> findAll() {
		// TODO Auto-generated method stub
		String sql = "select * from lumen_contacts";
		List<Contacts> contactList = new ArrayList<Contacts>();
		try (PreparedStatement pstmt = con.prepareStatement(sql)) {
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {

				String name = rs.getString("name");
				String address = rs.getString("address");
				Long mobileNumber = rs.getLong("mobileNumber");
				String img = rs.getString("img");
				LocalDate dateOfBirth = rs.getDate("dateOfBirth").toLocalDate();
				String email = rs.getString("email");

				Contacts contact = new Contacts(name, address, mobileNumber, img, dateOfBirth, email);
				contactList.add(contact);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return contactList;
	}

	@Override
	public int update(Contacts ex, Contacts update) {
		// TODO Auto-generated method stub
		String sql = "update lumen_contacts set docId=?, docName=?,mobilNum=?,specialization=?,dob=? where docId=?";
		int rowsUpdated = 0;
		try (PreparedStatement pstmt = con.prepareStatement(sql)) {
			pstmt.setString(1, update.getName());
			pstmt.setString(2, update.getAddress());
			pstmt.setLong(3, update.getMobileNumber());
			pstmt.setString(4, update.getImg());
			pstmt.setDate(5, Date.valueOf(update.getDateOfBirth()));
			pstmt.setString(6, ex.getEmail());

			rowsUpdated = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowsUpdated;
	}

	@Override
	public int remove(long mobileNumber) {
		int rowRemoved = 0;
		String sql = "delete from lumen_contacts where mobileNumber=?";
		try (PreparedStatement pstmt = con.prepareStatement(sql)) {
			pstmt.setLong(1, mobileNumber);
			rowRemoved = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rowRemoved;
	}

}
