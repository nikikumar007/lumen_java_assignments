package com.training.utils;

public enum SortOrder {
   Ascending,
   Descending;
}
